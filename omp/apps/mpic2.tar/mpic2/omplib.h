/* C header file for omplib.h */

void cinit_omp(int nth);

void csetnthsize(int nth);

int cgetnthsize();
