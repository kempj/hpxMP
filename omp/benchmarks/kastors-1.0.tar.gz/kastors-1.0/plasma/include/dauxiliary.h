/**
 *
 * @generated d Tue Jan  7 11:45:26 2014
 *
 **/
#ifndef DAUXILIARY_H
#define DAUXILIARY_H

double d_check_solution(int M, int N, int NRHS,
                      double *A1, int LDA,
                      double *B1, double *B2, int LDB);

#endif /* DAUXILIARY_H */
